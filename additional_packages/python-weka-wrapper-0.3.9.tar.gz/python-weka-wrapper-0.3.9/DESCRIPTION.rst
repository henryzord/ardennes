The **python-weka-wrapper** package makes it easy to run
Weka algorithms and filters from within Python. It offers access to Weka
API using thin wrappers around JNI calls using the **javabridge** package.
