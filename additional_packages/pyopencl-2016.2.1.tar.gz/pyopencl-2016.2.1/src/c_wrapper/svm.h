#ifndef __PYOPENCL_SVM_H
#define __PYOPENCL_SVM_H

#endif
