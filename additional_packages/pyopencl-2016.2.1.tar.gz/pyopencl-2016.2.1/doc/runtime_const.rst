OpenCL Runtime: Constants
=========================

.. include:: constants.inc
